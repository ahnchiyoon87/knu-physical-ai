import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
export default defineConfig({plugins:[vue()],server:{port:5173,strictPort:true,
  proxy:{'/api':'http://localhost:8000','/health':'http://localhost:8000','/trace':'http://localhost:8000'}}})
