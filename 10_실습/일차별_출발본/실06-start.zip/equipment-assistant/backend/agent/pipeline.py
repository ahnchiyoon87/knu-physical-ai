"""First workflow node chain: explicit stage contracts without approval or LLM routing."""
from typing import TypedDict
from langgraph.graph import StateGraph,START,END
from backend.common.response import reply
from backend.data.service import upload
from backend.detect.service import run_rules
from backend.ontology.gateway import flush_outbox


class PipelineState(TypedDict,total=False):
    rid:str
    profile:str
    source_id:str
    rule_id:str
    ingest:dict
    detection:dict
    projection:dict
    response:dict


def ingest(state):
    response=upload(state['rid'],state['profile'],state['source_id'])
    return {'ingest':response.model_dump(mode='json'),**({'response':response.model_dump(mode='json')} if response.status!='ok' else {})}


def detect(state):
    response=run_rules(state['rid'],state['profile'],state['source_id'],state['rule_id'])
    return {'detection':response.model_dump(mode='json'),**({'response':response.model_dump(mode='json')} if response.status!='ok' else {})}


def project(state):
    result=flush_outbox()
    return {'projection':result,'response':reply(state['rid'],{'ingest':state['ingest']['answer'],
        'detect':state['detection']['answer'],'graph':result,
        'scope':'적재·규칙 감지·관계 반영. CPU 예측은 별도 분석 실행'},
        meta={'warnings':['그래프 반영이 남았습니다'] if result.get('remaining') else []}).model_dump(mode='json')}


def run(rid,profile,source_id,rule_id):
    workflow=StateGraph(PipelineState)
    workflow.add_node('ingest',ingest);workflow.add_node('detect',detect);workflow.add_node('project',project)
    workflow.add_edge(START,'ingest')
    workflow.add_conditional_edges('ingest',lambda state:'stop' if state.get('response') else 'next',{'stop':END,'next':'detect'})
    workflow.add_conditional_edges('detect',lambda state:'stop' if state.get('response') else 'next',{'stop':END,'next':'project'})
    workflow.add_edge('project',END)
    result=workflow.compile().invoke({'rid':rid,'profile':profile,'source_id':source_id,'rule_id':rule_id})
    return result['response']
