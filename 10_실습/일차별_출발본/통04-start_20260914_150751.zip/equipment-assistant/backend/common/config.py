"""Configuration is explicit; missing credentials never select another provider."""
import json
import os
from functools import lru_cache
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]


@lru_cache
def settings() -> dict:
    return yaml.safe_load((ROOT / "config.yaml").read_text(encoding="utf-8"))


@lru_cache
def mapping() -> dict:
    return json.loads((ROOT / "mapping.json").read_text(encoding="utf-8"))


def env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise ValueError(f"설정이 없습니다: {name}")
    return value


def configured_path(value: str) -> Path:
    path = Path(value).expanduser()
    return path if path.is_absolute() else ROOT / path


def source(source_id: str, profile: str) -> dict:
    sources = mapping()["profiles"].get(profile, {}).get("sources", {})
    if source_id not in sources:
        raise ValueError(f"등록되지 않은 원천: {profile}/{source_id}")
    return sources[source_id]

