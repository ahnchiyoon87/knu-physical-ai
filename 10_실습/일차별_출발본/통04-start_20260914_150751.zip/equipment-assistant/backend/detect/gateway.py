"""Detection persistence and explicitly requested CPU model loading."""
from psycopg import sql
from psycopg.types.json import Jsonb

from backend.common.config import source
from backend.common.gateway import database
from backend.common.log import span
from backend.common.service import fingerprint


def all_series(profile: str, source_id: str, column_id: int, lot_id: str | None = None) -> list[dict]:
    config = source(source_id, profile)
    column = next((c for c in config["columns"] if c["id"] == column_id), None)
    if not column or column["type"] != "number":
        raise ValueError("수치 열 번호를 선택하세요")
    query = sql.SQL("SELECT row_no,lot_id,{} AS value FROM lab.{}").format(
        sql.Identifier(f"c{column_id}"), sql.Identifier(config["table"]))
    params = ()
    if lot_id is not None:
        query += sql.SQL(" WHERE lot_id=%s")
        params = (lot_id,)
    query += sql.SQL(" ORDER BY row_no")
    with span("detect", "detect.rule", "backend/detect/gateway.py:all_series", source=source_id), database(readonly=True) as db:
        return db.execute(query, params).fetchall()


def rule(rule_id: str):
    with database(readonly=True) as db:
        return db.execute("SELECT id,version,definition FROM lab.rules WHERE id=%s AND active", (rule_id,)).fetchone()


def save_events(profile: str, source_id: str, method: str, records: list[dict], provenance: str):
    with span("detect", "detect.event", "backend/detect/gateway.py:save_events", count=len(records)), database() as db:
        for row in records:
            identity = fingerprint([profile, source_id, method, row])
            db.execute("INSERT INTO lab.events(id,profile,source_id,lot_id,row_no,kind,method,payload) "
                       "VALUES(%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT(id) DO NOTHING",
                       (identity, profile, source_id, row.get("lot_id"), row.get("row_no"),
                        "alarm", method, Jsonb({**row, "provenance": provenance})))
            projection = {"id": identity, "kind": "alarm", "status": "observed", "provenance": provenance,
                          "targets": [f"{profile}:{source_id}:lot:{row['lot_id']}"] if row.get("lot_id") else []}
            db.execute("INSERT INTO lab.graph_outbox(id,payload) VALUES(%s,%s) ON CONFLICT(id) DO NOTHING",
                       (identity, Jsonb(projection)))


def events(profile: str, source_id: str, lot_id: str | None = None):
    with database(readonly=True) as db:
        return db.execute("SELECT id,lot_id,row_no,kind,method,payload FROM lab.events "
                          "WHERE profile=%s AND source_id=%s AND (%s::text IS NULL OR lot_id=%s) "
                          "ORDER BY row_no LIMIT 501", (profile, source_id, lot_id, lot_id)).fetchall()

