"""Pure alarm calculations preserve ordering, provenance and suppression counts."""
from statistics import fmean, pstdev
from backend.common.service import finite_number

def detect_rows(rows: list[dict], definition: dict) -> list[dict]:
    mode = definition['mode']
    if mode not in {'absolute', 'relative', 'combined'}:
        raise ValueError('지원하지 않는 규칙입니다')
    minimum = int(definition.get('baseline_count', 10))
    suppression = int(definition.get('suppression_shots', 0))
    if minimum < 2 or suppression < 0:
        raise ValueError('기준 구간과 억제 간격을 확인하세요')
    groups = {}
    for row in rows:
        groups.setdefault(row['lot_id'], []).append(row)
    alarms = []
    for samples in groups.values():
        samples = sorted(samples, key=lambda row: row['row_no'])
        if len({x['row_no'] for x in samples}) != len(samples):
            raise ValueError('같은 LOT 안에 순서가 중복됩니다')
        valid = [finite_number(x['value'], '감지값') for x in samples[:minimum] if x['value'] is not None]
        if mode != 'absolute' and len(valid) != minimum:
            raise ValueError('LOT 기준 구간에 필요한 유효 값이 부족합니다')
        mean = fmean(valid) if valid else None
        std = pstdev(valid) if valid else None
        last_notified = None
        for offset, row in enumerate(samples):
            if row['value'] is None:
                continue
            value = finite_number(row['value'], '감지값')
            low, high = (definition.get('lower'), definition.get('upper'))
            absolute = low is not None and value < low or (high is not None and value > high)
            if mode != 'absolute' and offset < minimum:
                continue
            if mode != 'absolute' and std == 0:
                relative = value != mean
            else:
                relative = False if mode == 'absolute' else abs(value - mean) > definition['width'] * std
            flagged = absolute if mode == 'absolute' else relative if mode == 'relative' else absolute and relative
            if flagged:
                suppressed = last_notified is not None and offset - last_notified <= suppression
                if not suppressed:
                    last_notified = offset
                alarms.append({**row, 'baseline_mean': mean, 'baseline_std': std, 'suppressed': suppressed, 'priority': definition.get('priority', 'review'), 'rule_version': definition['version']})
    return alarms

def classification_counts(expected: list[int], predicted: list[int]) -> dict:
    if not expected or len(expected) != len(predicted):
        raise ValueError('비교할 라벨 개수가 일치하지 않거나 비어 있습니다')
    if any((type(x) is not int or x not in (0, 1) for x in expected + predicted)):
        raise ValueError('라벨은 0 또는 1이어야 합니다')
    tp = sum((a == b == 1 for a, b in zip(expected, predicted)))
    tn = sum((a == b == 0 for a, b in zip(expected, predicted)))
    fp = sum((a == 0 and b == 1 for a, b in zip(expected, predicted)))
    fn = sum((a == 1 and b == 0 for a, b in zip(expected, predicted)))
    return {'tp': tp, 'tn': tn, 'fp': fp, 'fn': fn, 'n': len(expected), 'accuracy': (tp + tn) / len(expected), 'precision': tp / (tp + fp) if tp + fp else None, 'recall': tp / (tp + fn) if tp + fn else None}

def first_threshold_crossing(values: list[float], threshold: float, direction: str):
    if direction not in {'above', 'below'}:
        raise ValueError('임계 방향은 above 또는 below입니다')
    threshold = finite_number(threshold, '임계값')
    for index, value in enumerate(values, 1):
        value = finite_number(value, '예측값')
        if direction == 'above' and value >= threshold or (direction == 'below' and value <= threshold):
            return index
    return None
