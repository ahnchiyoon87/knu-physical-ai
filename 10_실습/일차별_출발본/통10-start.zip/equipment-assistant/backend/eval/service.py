"""Expected evidence and status checks remain separate from model judgements."""
from backend.common.response import reply
from backend.common.service import fingerprint
from backend.rag import service as rag

from . import gateway


def score_contract(case: dict, response: dict) -> dict:
    actual = {item.get("document_id") for item in response["evidence"] if item["kind"] == "doc"}
    expected = set(case.get("expected_documents", []))
    claim_ids = [index for claim in response.get("answer") or [] if isinstance(claim, dict)
                 for index in claim.get("evidence_ids", [])]
    numbered = {item.get("id") for item in response["evidence"]}
    checks = {
        "status": response["status"] in case["expected_statuses"],
        "current_documents": all(item.get("status") == "current" for item in response["evidence"] if item["kind"] == "doc"),
        "expected_evidence": expected.issubset(actual),
        "valid_citation_ids": all(index in numbered for index in claim_ids),
        "nonempty_answer_has_evidence": response["status"] != "ok" or bool(response["evidence"]),
    }
    return {"checks": checks, "passed": sum(checks.values()), "total": len(checks),
            "semantic_judgement": "미판정: 계약 검사만으로 주장 지지와 정답을 확정하지 않음"}


def run(rid: str, profile: str, provider: str, cases: list[dict]):
    if not cases or len(cases) > 100:
        raise ValueError("질문셋은 1~100개입니다")
    if len({case["id"] for case in cases}) != len(cases):
        raise ValueError("질문 ID가 중복됩니다")
    results = []
    for case in cases:
        result = rag.ask(rid, profile, case["question"], provider)
        encoded = result.model_dump(mode="json")
        scores = score_contract(case, encoded)
        results.append({"case_id": case["id"], "question": case["question"], "result": encoded, "contract": scores})
    identity = fingerprint([rid, profile, provider, cases])
    answer = {"id": identity, "profile": profile, "provider": provider, "question_set_hash": fingerprint(cases),
              "results": results, "scope": "검색·답변 실행 및 계약 검사. RAGAS 모델 심사는 별도 실행"}
    gateway.save(identity, rid, provider, answer)
    return reply(rid, answer)

