# 임시 데이터 생성기 — 사출성형기 IM-02 시나리오
# 변수 이름·단위·기준 통계: KAMP 「사출성형기 AI 데이터셋」 분석실습 가이드북(UNIST) 기술통계(moldset_labeled)
# 사건(가정): 2026-07-22 금형 코어핀 교체(정비이력에 '경미'로 기록, 4M 미신고) → 이후 LOT 내경 단조 증가
import numpy as np, pandas as pd, json, os, datetime as dt
rng = np.random.default_rng(20260909)
OUT = "/home/claude/w/tempdata"; os.makedirs(OUT, exist_ok=True)
os.makedirs(f"{OUT}/센서", exist_ok=True); os.makedirs(f"{OUT}/공장문서", exist_ok=True); os.makedirs(f"{OUT}/기록", exist_ok=True)

# ---------- 1) 센서 (샷 단위, KAMP 변수명·기술통계) ----------
# 가이드북 표 21쪽 평균/표준편차 (0 고정 채널은 실제 데이터의 특성 그대로 둠)
stats = {
 "Injection_Time":(9.52,0.30), "Filling_Time":(4.41,0.20), "Plasticizing_Time":(16.78,0.60), "Cycle_Time":(60.54,1.13),
 "Clamp_Close_Time":(6.98,0.16), "Cushion_Position":(653.80,0.42), "Switch_Over_Position":(0.0,0.0),
 "Plasticizing_Position":(61.79,7.48), "Clamp_Open_Position":(647.99,0.0), "Max_Injection_Speed":(88.64,3.0),
 "Max_Screw_RPM":(30.80,0.12), "Average_Screw_RPM":(291.60,0.98), "Max_Injection_Pressure":(142.18,0.48),
 "Max_Switch_Over_Pressure":(127.33,3.0), "Max_Back_Pressure":(46.18,2.0), "Average_Back_Pressure":(60.13,1.10),
 "Barrel_Temperature_1":(280.60,1.0), "Barrel_Temperature_2":(279.78,1.0), "Barrel_Temperature_3":(279.53,1.0),
 "Barrel_Temperature_4":(272.66,0.8), "Barrel_Temperature_5":(259.54,0.8), "Barrel_Temperature_6":(232.25,0.6),
 "Barrel_Temperature_7":(0.0,0.0), "Hopper_Temperature":(66.72,0.5),
 "Mold_Temperature_1":(0,0),"Mold_Temperature_2":(0,0),"Mold_Temperature_3":(22.81,0.6),"Mold_Temperature_4":(24.18,0.7),
 "Mold_Temperature_5":(0,0),"Mold_Temperature_6":(0,0),"Mold_Temperature_7":(0,0),"Mold_Temperature_8":(0,0),
 "Mold_Temperature_9":(0,0),"Mold_Temperature_10":(0,0),"Mold_Temperature_11":(0,0),"Mold_Temperature_12":(0,0),
}
start = dt.datetime(2026,6,22,8,0,0); end = dt.datetime(2026,8,21,17,0,0)
EVENT = dt.datetime(2026,7,22,13,40,0)          # 코어핀 교체(정비 종료 시각)
rows=[]; t=start; shot=0; lot_seq={}
while t < end:
    if t.weekday()>=5 or not (8<=t.hour<17): t += dt.timedelta(minutes=5); continue
    if 12<=t.hour<13: t += dt.timedelta(minutes=5); continue
    shot+=1
    day=t.date(); lot_seq.setdefault(day,0)
    lot = f"L{day.strftime('%y%m%d')}-{'A' if t.hour<13 else 'B'}"
    r={"TimeStamp":t.strftime("%Y-%m-%d %H:%M:%S"),"PART_FACT_PLAN_DATE":day.strftime("%Y%m%d"),"PART_NO":"BRK-2210",
       "PART_NAME":"브래킷 BRK-2210","EQUIP_CD":"IM-02","EQUIP_NAME":"650톤 사출기 2호기","LOT_NO":lot,"Shot_No":shot}
    days_after = max(0,(t-EVENT).total_seconds()/86400)
    for k,(m,s) in stats.items():
        v = m + rng.normal(0,s) if s>0 else m
        # 가정: 코어핀 교체 뒤 캐비티 체적 미세 변화 → 쿠션 위치·보압 절환 압력이 아주 서서히 이동
        if k=="Cushion_Position": v += 0.012*days_after
        if k=="Max_Switch_Over_Pressure": v -= 0.08*days_after
        r[k]=round(float(v),2)
    rows.append(r); t += dt.timedelta(seconds=r["Cycle_Time"])
df=pd.DataFrame(rows)
# ---- 심어 두는 잡음 5종 (학생이 찾아낼 것) ----
n=len(df)
idx=rng.choice(n, size=int(n*0.004), replace=False); df.loc[idx,"Barrel_Temperature_3"]=np.nan                    # ① 결측
idx=rng.choice(n, size=8, replace=False); df.loc[idx,"Max_Injection_Pressure"]=df.loc[idx,"Max_Injection_Pressure"]+rng.normal(40,5,8)  # ② 스파이크
d=df["TimeStamp"].str.startswith("2026-07-08"); df.loc[d,"Mold_Temperature_3"]=df.loc[d,"Mold_Temperature_3"]*9/5+32              # ③ 단위 오류(하루 ℉)
d=df["TimeStamp"].str.startswith("2026-07-15"); df.loc[d,"Hopper_Temperature"]=66.50                                             # ④ 고정값(센서 멈춤)
dup=df.sample(30, random_state=1); df=pd.concat([df,dup]).sort_values("TimeStamp")                                                  # ⑤ 중복 행
df.to_csv(f"{OUT}/센서/IM-02_shot_2026-06-22_2026-08-21.csv", index=False, encoding="utf-8-sig")
# 열 이름을 코드로 바꾼 판 (카탈로그 복원 실습용)
codes={c:f"C{i:03d}" for i,c in enumerate(df.columns)}
df.rename(columns=codes).to_csv(f"{OUT}/센서/TB_IM02_RAW.csv", index=False, encoding="utf-8-sig")
open(f"{OUT}/센서/collect_im02.py","w",encoding="utf-8").write(
"# IM-02 PLC 수집 스크립트 (발췌). TB_IM02_RAW 적재용.\n" + "\n".join(
 f"# {v}: {k}" + ("  # 초. 고압 사출 구간" if k=="Injection_Time" else "  # mm. 보압 시작 시점 스크류 위치(과충전 방지)" if k=="Cushion_Position" else "  # MPa. 사출→보압 절환 압력" if k=="Max_Switch_Over_Pressure" else "  # ℃. 배럴 존별 온도" if k.startswith("Barrel") else "  # ℃. 금형 온도(3,4번만 센서 연결)" if k.startswith("Mold") else "") for k,v in codes.items()))

# ---------- 2) 검사기록 (LOT 단위 내경, 이벤트 뒤 단조 증가) ----------
lots=sorted(df["LOT_NO"].unique()); insp=[]
for i,l in enumerate(lots):
    day=dt.datetime.strptime(l[1:7],"%y%m%d"); after=max(0,(day-EVENT.replace(hour=0)).days)
    base=8.012 + (0.0016*after if after>0 else 0)
    vals=[round(base+rng.normal(0,0.004),3) for _ in range(5)]
    insp_id = "임꺽정" if day.day%2 else "성춘향"
    rec={"LOT_NO":l,"검사일":day.strftime("%Y-%m-%d"),"검사자":insp_id,"항목":"내경 φ8.00 (+0.05/-0.00)","단위":"mm",
         "측정1":vals[0],"측정2":vals[1],"측정3":vals[2],"측정4":vals[3],"측정5":vals[4],"판정":"합격" if max(vals)<=8.050 else "불합격","비고":""}
    if l in ("L260724-B","L260731-A"): rec.update({k:"" for k in ["측정1","측정2","측정3","측정4","측정5"]}); rec["판정"]="미기록"; rec["비고"]="종물검사 누락"
    if l=="L260805-A": rec.update({f"측정{j}":round(v*1000) for j,v in enumerate(vals,1)}); rec["비고"]="단위 확인 필요"   # 단위 오류(µm 기입)
    insp.append(rec)
pd.DataFrame(insp).to_csv(f"{OUT}/기록/검사기록_BRK-2210_2026.csv",index=False,encoding="utf-8-sig")

# ---------- 3) 생산 · 재고 ----------
prod=df.groupby(["LOT_NO","PART_FACT_PLAN_DATE"]).size().reset_index(name="생산수량")
prod["작업자"]=[("심청" if int(l[5:7])%2 else "변강쇠") for l in prod["LOT_NO"]]
prod["출하상태"]=["출하완료" if l< "L260801" else "사내재고" for l in prod["LOT_NO"]]
prod.to_csv(f"{OUT}/기록/생산실적_2026.csv",index=False,encoding="utf-8-sig")
stock=prod[prod["출하상태"]=="사내재고"][["LOT_NO","생산수량"]].rename(columns={"생산수량":"재고수량"}); stock["창고"]="완제품 A동"
stock.to_csv(f"{OUT}/기록/재고현황_2026-08-21.csv",index=False,encoding="utf-8-sig")

# ---------- 4) 매핑 파일 · 온톨로지 첫 판 ----------
mapping={"설비":{"코드":"IM-02","이름":"650톤 사출기 2호기","제품":"BRK-2210"},
 "센서파일":"센서/IM-02_shot_2026-06-22_2026-08-21.csv","시간열":"TimeStamp","LOT열":"LOT_NO",
 "채널":{"Cushion_Position":{"뜻":"보압 시작 시점 스크류 위치","단위":"mm","정상범위":[652.5,655.5]},
         "Max_Switch_Over_Pressure":{"뜻":"사출→보압 절환 압력","단위":"MPa","정상범위":[110,147]},
         "Max_Injection_Pressure":{"뜻":"최대 사출압","단위":"MPa","정상범위":[140,148]},
         "Barrel_Temperature_3":{"뜻":"배럴 3존 온도","단위":"℃","정상범위":[270,290]},
         "Mold_Temperature_3":{"뜻":"금형 온도 3","단위":"℃","정상범위":[19,26]},
         "Hopper_Temperature":{"뜻":"호퍼 온도","단위":"℃","정상범위":[62,71]},
         "Cycle_Time":{"뜻":"1샷 생산 시간","단위":"초","정상범위":[57,64]}},
 "검사파일":"기록/검사기록_BRK-2210_2026.csv","검사항목":"내경","공차":[8.000,8.050],
 "출처":"변수명·단위·기준 통계는 KAMP 사출성형기 AI 데이터셋 가이드북(UNIST). 값은 임의 생성. 기업 데이터가 오면 이 파일만 고친다"}
json.dump(mapping, open(f"{OUT}/mapping.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
onto=[("클래스","설비","IM-02 같은 사출기"),("클래스","센서채널","Cushion_Position 같은 열"),("클래스","LOT","하루 두 번 나뉘는 생산 묶음"),
 ("클래스","측정","LOT별 내경 측정"),("클래스","이상이벤트","규칙/모델이 잡은 이상"),("클래스","정비이력","점검·부품 교체 기록"),
 ("클래스","문서","작업표준서·절차서"),("클래스","조항","문서 안의 번호 붙은 항"),("클래스","사람","작업자·검사자·승인권자"),("클래스","조치","에이전트가 제안하고 사람이 승인한 것"),
 ("관계","설비 -has-> 센서채널","EQUIP_CD"),("관계","LOT -produced_on-> 설비","EQUIP_CD + 날짜"),("관계","측정 -of-> LOT","LOT_NO"),
 ("관계","이상이벤트 -on-> 설비 · -covers-> LOT","EQUIP_CD, LOT_NO"),("관계","정비이력 -on-> 설비","설비코드"),
 ("관계","정비이력 -classified_by-> 조항","절차서 문서번호 + 조항번호"),("관계","조항 -in-> 문서","문서번호"),("관계","조치 -based_on-> 조항, -approved_by-> 사람","문서번호+조항, 사번")]
pd.DataFrame(onto,columns=["종류","이름","어느 키로 잇는가 / 뜻"]).to_csv(f"{OUT}/온톨로지_첫판.csv",index=False,encoding="utf-8-sig")
print("shots",len(df),"lots",len(lots))
