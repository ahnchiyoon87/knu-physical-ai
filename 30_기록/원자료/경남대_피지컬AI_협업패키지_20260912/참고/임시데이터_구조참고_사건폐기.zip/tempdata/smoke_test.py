import duckdb, json, pandas as pd, networkx as nx, re
D="/home/claude/w/tempdata"; m=json.load(open(f"{D}/mapping.json",encoding="utf-8"))
con=duckdb.connect()
con.execute(f"CREATE VIEW shot AS SELECT * FROM read_csv_auto('{D}/{m['센서파일']}', header=true)")
con.execute(f"CREATE VIEW insp AS SELECT * FROM read_csv_auto('{D}/{m['검사파일']}', header=true, all_varchar=true)")
con.execute(f"CREATE VIEW prod AS SELECT * FROM read_csv_auto('{D}/기록/생산실적_2026.csv', header=true)")
con.execute(f"CREATE VIEW stock AS SELECT * FROM read_csv_auto('{D}/기록/재고현황_2026-08-21.csv', header=true)")
print("== ① 한 창구(DuckDB)로 파일 넷 조회")
print(con.sql("SELECT (SELECT count(*) FROM shot) shots,(SELECT count(*) FROM insp) lots_insp,(SELECT count(*) FROM prod) lots_prod,(SELECT count(*) FROM stock) stock_lots").df().to_string(index=False))

print("\n== ① 잡음 5종 — 데이터 품질 검사")
q={"결측(Barrel_Temperature_3)":"SELECT count(*) FROM shot WHERE Barrel_Temperature_3 IS NULL",
   "스파이크(Max_Injection_Pressure>155)":"SELECT count(*) FROM shot WHERE Max_Injection_Pressure>155",
   "단위오류 의심(Mold_Temperature_3>40)":"SELECT count(DISTINCT strftime(TimeStamp,'%Y-%m-%d')) FROM shot WHERE Mold_Temperature_3>40",
   "고정값(Hopper 하루 표준편차 0인 날)":"SELECT count(*) FROM (SELECT strftime(TimeStamp,'%Y-%m-%d') d, stddev(Hopper_Temperature) s FROM shot GROUP BY d HAVING s=0)",
   "중복 행":"SELECT count(*)-count(DISTINCT CAST(TimeStamp AS VARCHAR)||Shot_No) FROM shot"}
for k,v in q.items(): print(f"  {k}: {con.sql(v).fetchone()[0]}")

print("\n== ①→② 규칙 기반 탐지 — LOT별 쿠션 위치 평균이 기준 653.8±1.5 를 벗어나는가 / 주간 드리프트")
wk=con.sql("""SELECT strftime(TimeStamp,'%Y-W%V') w, round(avg(Cushion_Position),3) cushion, round(avg(Max_Switch_Over_Pressure),2) sw_p
             FROM shot GROUP BY w ORDER BY w""").df(); print(wk.to_string(index=False))
alarm_abs=con.sql("SELECT count(*) FROM shot WHERE Cushion_Position>655.3 OR Cushion_Position<652.3").fetchone()[0]
print(f"  절대 규칙(±1.5) 알람 샷 수: {alarm_abs}  ← 절대 임계로는 거의 안 잡힘")
first=con.sql("""WITH d AS (SELECT strftime(TimeStamp,'%Y-%m-%d') AS dd, avg(Cushion_Position) c FROM shot GROUP BY dd),
 b AS (SELECT avg(c) base, stddev(c) sd FROM d WHERE dd<'2026-07-22')
 SELECT min(dd) FROM d, b WHERE d.c > b.base + 3*b.sd""").fetchone()[0]
print(f"  상대 규칙(기준 구간 평균+3σ, 일 평균) 첫 알람일: {first}   (사건일 2026-07-22)")

print("\n== 검사기록 — 내경 추세 · 미기록 · 단위 오류")
tr=con.sql("""SELECT 검사일, 판정, 측정1 FROM insp WHERE 검사일 IN ('2026-07-01','2026-07-21','2026-07-31','2026-08-12','2026-08-20') ORDER BY 검사일""").df()
print(tr.to_string(index=False))
print("  미기록 LOT:", con.sql("SELECT list(LOT_NO) FROM insp WHERE 판정='미기록'").fetchone()[0])
print("  단위 의심 LOT:", con.sql("SELECT list(LOT_NO) FROM insp WHERE TRY_CAST(측정1 AS DOUBLE)>100").fetchone()[0])
print("  첫 불합격 LOT:", con.sql("SELECT min(LOT_NO) FROM insp WHERE 판정='불합격'").fetchone()[0])

print("\n== 교차 검증 — 생산 = 사내재고 + 출하완료 ?")
print(con.sql("""SELECT (SELECT sum(생산수량) FROM prod WHERE 출하상태='사내재고') AS 사내_생산,
                        (SELECT sum(재고수량) FROM stock) AS 재고합,
                        (SELECT count(*) FROM prod p LEFT JOIN insp i USING(LOT_NO) WHERE i.LOT_NO IS NULL) AS 검사없는_LOT""").df().to_string(index=False))

print("\n== ② 온톨로지 첫 판 → 그래프 → 4홉")
G=nx.DiGraph()
G.add_edge("이상이벤트:2026-07-27 쿠션 드리프트","설비:IM-02",rel="on")
for _,r in pd.read_csv(f"{D}/기록/생산실적_2026.csv").iterrows(): G.add_edge(f"LOT:{r.LOT_NO}","설비:IM-02",rel="produced_on")
log=open(f"{D}/공장문서/EQ-IM02_설비점검이력_2026.md",encoding="utf-8").read()
for line in log.splitlines():
    c=[x.strip() for x in line.strip("|").split("|")]
    if len(c)==7 and re.match(r"\d{4}-\d{2}-\d{2}",c[0]):
        n=f"정비:{c[0]} {c[2][:22]}"; G.add_edge("설비:IM-02",n,rel="has_maintenance")
        if "코어핀" in c[2]: G.add_edge(n,"조항:QP-4M-002 §5.1",rel="classified_by"); G.add_edge(n,"조항:QP-4M-002 §6.2",rel="flagged_by")
G.add_edge("조항:QP-4M-002 §5.1","문서:QP-4M-002 RevB",rel="in"); G.add_edge("조항:QP-4M-002 §6.2","문서:QP-4M-002 RevB",rel="in")
print("  노드",G.number_of_nodes(),"엣지",G.number_of_edges())
p=nx.shortest_path(G.to_undirected(),"이상이벤트:2026-07-27 쿠션 드리프트","조항:QP-4M-002 §5.1")
print("  경로:", " → ".join(p), f"({len(p)-1}홉)")
