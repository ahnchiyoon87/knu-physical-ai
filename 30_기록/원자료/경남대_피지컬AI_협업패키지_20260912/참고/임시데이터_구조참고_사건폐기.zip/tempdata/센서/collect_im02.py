# IM-02 PLC 수집 스크립트 (발췌). TB_IM02_RAW 적재용.
# C000: TimeStamp
# C001: PART_FACT_PLAN_DATE
# C002: PART_NO
# C003: PART_NAME
# C004: EQUIP_CD
# C005: EQUIP_NAME
# C006: LOT_NO
# C007: Shot_No
# C008: Injection_Time  # 초. 고압 사출 구간
# C009: Filling_Time
# C010: Plasticizing_Time
# C011: Cycle_Time
# C012: Clamp_Close_Time
# C013: Cushion_Position  # mm. 보압 시작 시점 스크류 위치(과충전 방지)
# C014: Switch_Over_Position
# C015: Plasticizing_Position
# C016: Clamp_Open_Position
# C017: Max_Injection_Speed
# C018: Max_Screw_RPM
# C019: Average_Screw_RPM
# C020: Max_Injection_Pressure
# C021: Max_Switch_Over_Pressure  # MPa. 사출→보압 절환 압력
# C022: Max_Back_Pressure
# C023: Average_Back_Pressure
# C024: Barrel_Temperature_1  # ℃. 배럴 존별 온도
# C025: Barrel_Temperature_2  # ℃. 배럴 존별 온도
# C026: Barrel_Temperature_3  # ℃. 배럴 존별 온도
# C027: Barrel_Temperature_4  # ℃. 배럴 존별 온도
# C028: Barrel_Temperature_5  # ℃. 배럴 존별 온도
# C029: Barrel_Temperature_6  # ℃. 배럴 존별 온도
# C030: Barrel_Temperature_7  # ℃. 배럴 존별 온도
# C031: Hopper_Temperature
# C032: Mold_Temperature_1  # ℃. 금형 온도(3,4번만 센서 연결)
# C033: Mold_Temperature_2  # ℃. 금형 온도(3,4번만 센서 연결)
# C034: Mold_Temperature_3  # ℃. 금형 온도(3,4번만 센서 연결)
# C035: Mold_Temperature_4  # ℃. 금형 온도(3,4번만 센서 연결)
# C036: Mold_Temperature_5  # ℃. 금형 온도(3,4번만 센서 연결)
# C037: Mold_Temperature_6  # ℃. 금형 온도(3,4번만 센서 연결)
# C038: Mold_Temperature_7  # ℃. 금형 온도(3,4번만 센서 연결)
# C039: Mold_Temperature_8  # ℃. 금형 온도(3,4번만 센서 연결)
# C040: Mold_Temperature_9  # ℃. 금형 온도(3,4번만 센서 연결)
# C041: Mold_Temperature_10  # ℃. 금형 온도(3,4번만 센서 연결)
# C042: Mold_Temperature_11  # ℃. 금형 온도(3,4번만 센서 연결)
# C043: Mold_Temperature_12  # ℃. 금형 온도(3,4번만 센서 연결)